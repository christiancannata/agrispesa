"use strict";

function wcccf_init_user_role_select2()
{
	jQuery(".js-data-user-role").select2(
		{
			width:300,
			 minimumInputLength: 0
		});
}